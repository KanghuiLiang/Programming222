package programming2Week2;

public interface Travel {
	void Travel();
}
