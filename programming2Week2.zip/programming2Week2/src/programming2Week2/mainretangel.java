package programming2Week2;

public class mainretangel {
	
	public static void main (String arg[]) {
		Retangle r1 = new Retangle(10,10,10,10);
//		System.out.println(r1.coordinate.x+r1.coordinate.y);
//		System.out.println(r1.coordinate);
		r1.showlocation();
	}

}
