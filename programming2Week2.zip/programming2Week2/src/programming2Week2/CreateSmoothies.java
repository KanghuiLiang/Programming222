package programming2Week2;

public class CreateSmoothies {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Smoothies S1 = new Smoothies();
		Smoothies S2 = new Smoothies(1,2, "Apple","Water",false,"0s","");
		
		S1.CheckPreparation();
		System.out.println(S1);
		S1.SmoothiesReady(true);
		
		System.out.println("---------");
		S2.CheckPreparation();
		System.out.println(S2);
		S2.SmoothiesReady(false);
		
		System.out.println("---------");
        S1.addML(10);
        S1.SmoothiesReady(true);
	}

}
