package programming2Week2;

public interface Defense {
	void Defense();

}
